"""
Backend validation for all simulation inputs.
Raises ValueError with user-friendly messages on invalid input.
"""

LIMITS = {
    "salary_annual_min": 0,
    "salary_annual_max": 100_000_000,
    "balance_min": 0,
    "balance_max": 1_000_000_000,
    "monthly_expenses_min": 0,
    "monthly_expenses_max": 1_000_000,
    "savings_rate_min": 0,
    "savings_rate_max": 100,
    "debt_min": 0,
    "debt_max": 100_000_000,
    "annual_return_min": -50,
    "annual_return_max": 100,
    "years_min": 1,
    "years_max": 60,
    "inflation_min": 0,
    "inflation_max": 50,
}


def validate_simulation_inputs(data: dict) -> dict:
    errors = []

    def require_float(key, label, min_val, max_val, default=None):
        raw = data.get(key, default)
        if raw is None or str(raw).strip() == "":
            if default is not None:
                return float(default)
            errors.append(f"{label} is required.")
            return None
        try:
            val = float(raw)
        except (TypeError, ValueError):
            errors.append(f"{label} must be a number.")
            return None
        if val < min_val:
            errors.append(f"{label} must be at least {min_val}.")
            return None
        if val > max_val:
            errors.append(f"{label} must be at most {max_val:,}.")
            return None
        return val

    def require_int(key, label, min_val, max_val, default=None):
        raw = data.get(key, default)
        try:
            val = int(float(raw))
        except (TypeError, ValueError):
            errors.append(f"{label} must be a whole number.")
            return None
        if val < min_val or val > max_val:
            errors.append(f"{label} must be between {min_val} and {max_val}.")
            return None
        return val

    # Salary — handle monthly vs annual
    salary_period = data.get("salary_period", "annual")
    raw_salary = require_float("salary", "Salary", 0, LIMITS["salary_annual_max"])
    if raw_salary is not None:
        annual_salary = raw_salary * 12 if salary_period == "monthly" else raw_salary
        if annual_salary > LIMITS["salary_annual_max"]:
            errors.append("Salary seems unrealistically high.")
            annual_salary = None
    else:
        annual_salary = None

    balance       = require_float("balance",          "Current Balance",    LIMITS["balance_min"],          LIMITS["balance_max"],          default=0)
    monthly_exp   = require_float("monthly_expenses", "Monthly Expenses",   LIMITS["monthly_expenses_min"], LIMITS["monthly_expenses_max"])
    savings_rate  = require_float("savings_rate",     "Savings Rate",       LIMITS["savings_rate_min"],     LIMITS["savings_rate_max"])
    debt          = require_float("debt",             "Debt",               LIMITS["debt_min"],             LIMITS["debt_max"],             default=0)
    annual_return = require_float("annual_return",    "Annual Return",      LIMITS["annual_return_min"],    LIMITS["annual_return_max"])
    years         = require_int("years",              "Years",              LIMITS["years_min"],            LIMITS["years_max"])
    inflation     = require_float("inflation_rate",   "Inflation Rate",     LIMITS["inflation_min"],        LIMITS["inflation_max"],        default=2.5)

    # Cross-field sanity checks
    if annual_salary is not None and monthly_exp is not None:
        if monthly_exp > annual_salary / 12 * 1.5:
            errors.append("Monthly expenses exceed 150% of monthly income — please double-check.")

    if errors:
        raise ValueError(" | ".join(errors))

    return {
        "salary": annual_salary,
        "salary_period": salary_period,
        "balance": balance,
        "monthly_expenses": monthly_exp,
        "savings_rate": savings_rate,
        "debt": debt,
        "annual_return": annual_return,
        "years": years,
        "inflation_rate": inflation,
    }


def validate_goal_input(data: dict) -> dict:
    errors = []
    name = str(data.get("name", "")).strip()
    if not name:
        errors.append("Goal name is required.")
    if len(name) > 100:
        errors.append("Goal name must be under 100 characters.")

    try:
        target = float(data["target_amount"])
        assert 1 <= target <= 100_000_000
    except Exception:
        errors.append("Target amount must be between 1 and 100,000,000.")
        target = None

    try:
        current = float(data.get("current_amount", 0))
        assert 0 <= current <= 100_000_000
    except Exception:
        errors.append("Current amount must be between 0 and 100,000,000.")
        current = 0

    deadline = data.get("deadline_months")
    if deadline is not None:
        try:
            deadline = int(deadline)
            assert 1 <= deadline <= 600
        except Exception:
            errors.append("Deadline must be between 1 and 600 months.")
            deadline = None

    category = data.get("category", "other")
    valid_cats = {"house", "car", "education", "emergency", "retirement", "travel", "investment", "other"}
    if category not in valid_cats:
        category = "other"

    if errors:
        raise ValueError(" | ".join(errors))

    return {"name": name, "target_amount": target, "current_amount": current,
            "deadline_months": deadline, "category": category}
