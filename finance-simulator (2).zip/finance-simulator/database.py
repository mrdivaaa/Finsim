import sqlite3
import json
import uuid
from datetime import datetime
from pathlib import Path

DB_PATH = Path(__file__).parent / "finsim.db"


def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with get_connection() as conn:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS simulations (
                id          TEXT PRIMARY KEY,
                created_at  TEXT NOT NULL,
                label       TEXT,
                inputs      TEXT NOT NULL,
                results     TEXT NOT NULL,
                summary     TEXT NOT NULL,
                tax_info    TEXT,
                advice      TEXT
            );

            CREATE TABLE IF NOT EXISTS goals (
                id              TEXT PRIMARY KEY,
                simulation_id   TEXT,
                name            TEXT NOT NULL,
                target_amount   REAL NOT NULL,
                current_amount  REAL DEFAULT 0,
                deadline_months INTEGER,
                category        TEXT,
                created_at      TEXT NOT NULL,
                FOREIGN KEY (simulation_id) REFERENCES simulations(id)
            );
        """)


def save_simulation(inputs: dict, results: list, summary: dict,
                    tax_info: dict = None, advice: str = None, label: str = None) -> str:
    sim_id = str(uuid.uuid4())[:8]
    now = datetime.utcnow().isoformat()
    with get_connection() as conn:
        conn.execute(
            """INSERT INTO simulations (id, created_at, label, inputs, results, summary, tax_info, advice)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (sim_id, now, label or f"Simulation {now[:10]}",
             json.dumps(inputs), json.dumps(results),
             json.dumps(summary), json.dumps(tax_info), advice)
        )
    return sim_id


def get_simulation(sim_id: str) -> dict | None:
    with get_connection() as conn:
        row = conn.execute("SELECT * FROM simulations WHERE id=?", (sim_id,)).fetchone()
    if not row:
        return None
    return {
        "id": row["id"],
        "created_at": row["created_at"],
        "label": row["label"],
        "inputs": json.loads(row["inputs"]),
        "results": json.loads(row["results"]),
        "summary": json.loads(row["summary"]),
        "tax_info": json.loads(row["tax_info"]) if row["tax_info"] else None,
        "advice": row["advice"],
    }


def list_simulations(limit: int = 20) -> list:
    with get_connection() as conn:
        rows = conn.execute(
            "SELECT id, created_at, label, summary FROM simulations ORDER BY created_at DESC LIMIT ?",
            (limit,)
        ).fetchall()
    return [
        {"id": r["id"], "created_at": r["created_at"], "label": r["label"],
         "summary": json.loads(r["summary"])}
        for r in rows
    ]


def delete_simulation(sim_id: str):
    with get_connection() as conn:
        conn.execute("DELETE FROM simulations WHERE id=?", (sim_id,))


def save_goal(name: str, target: float, current: float = 0,
              deadline_months: int = None, category: str = "other",
              simulation_id: str = None) -> str:
    goal_id = str(uuid.uuid4())[:8]
    now = datetime.utcnow().isoformat()
    with get_connection() as conn:
        conn.execute(
            """INSERT INTO goals (id, simulation_id, name, target_amount, current_amount,
               deadline_months, category, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (goal_id, simulation_id, name, target, current, deadline_months, category, now)
        )
    return goal_id


def list_goals() -> list:
    with get_connection() as conn:
        rows = conn.execute("SELECT * FROM goals ORDER BY created_at DESC").fetchall()
    return [dict(r) for r in rows]


def delete_goal(goal_id: str):
    with get_connection() as conn:
        conn.execute("DELETE FROM goals WHERE id=?", (goal_id,))
