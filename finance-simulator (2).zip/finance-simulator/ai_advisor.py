"""
AI advisor module. Returns structured JSON advice with sections:
Summary, Issues, Action Steps, Strategy.
"""

import json
import os
import urllib.request


def _call_claude(prompt: str, max_tokens: int = 1200) -> str:
    api_key = os.environ.get("ANTHROPIC_API_KEY", "")
    headers = {
        "Content-Type":    "application/json",
        "anthropic-version": "2023-06-01",
    }
    if api_key:
        headers["x-api-key"] = api_key

    payload = json.dumps({
        "model":      "claude-sonnet-4-20250514",
        "max_tokens": max_tokens,
        "messages":   [{"role": "user", "content": prompt}],
    }).encode("utf-8")

    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=payload, headers=headers, method="POST"
    )
    with urllib.request.urlopen(req, timeout=30) as resp:
        data = json.loads(resp.read().decode())
        return data["content"][0]["text"]


def get_ai_advice(user_data: dict, summary: dict, tax_info: dict = None) -> dict:
    """
    Returns a structured dict with keys: summary, issues, action_steps, strategy.
    Each is a plain-text string (no markdown).
    """
    tax_str = ""
    if tax_info:
        tax_str = f"""
Tax context ({tax_info['country']}):
- Gross annual income: {tax_info['symbol']}{tax_info['gross_annual']:,.0f}
- Estimated income tax: {tax_info['symbol']}{tax_info['income_tax']:,.0f}
- Social security/NI: {tax_info['symbol']}{tax_info['social_security']:,.0f}
- Net annual income: {tax_info['symbol']}{tax_info['net_annual']:,.0f} (effective rate: {tax_info['effective_rate']}%)
"""

    prompt = f"""You are a sharp, expert personal finance advisor. Analyze this person's finances and respond ONLY with a valid JSON object — no markdown, no backticks, no extra text.

Financial inputs:
- Annual salary (gross): {user_data.get('symbol','$')}{user_data['salary']:,.0f}
- Current balance/savings: {user_data.get('symbol','$')}{user_data.get('balance', 0):,.0f}
- Monthly expenses: {user_data.get('symbol','$')}{user_data['monthly_expenses']:,.0f}
- Savings rate: {user_data['savings_rate']}%
- Current debt: {user_data.get('symbol','$')}{user_data['debt']:,.0f}
- Expected annual return: {user_data['annual_return']}%
- Simulation: {user_data['years']} years
{tax_str}
Projections:
- Final net worth: {user_data.get('symbol','$')}{summary['final_net_worth']:,.0f}
- Inflation-adjusted: {user_data.get('symbol','$')}{summary['final_real_net_worth']:,.0f}
- Total gains from investing: {user_data.get('symbol','$')}{summary['total_gains']:,.0f}
{"- Debt-free by year: " + str(summary['debt_free_year']) if summary.get('debt_free_year') else ""}
{"- FIRE possible by year: " + str(summary['fire_year']) if summary.get('fire_year') else "- FIRE not reached in simulation period"}

Respond with ONLY this JSON structure (strings only, no nested objects, no lists):
{{
  "summary": "2-3 sentence overall assessment of their financial health and trajectory.",
  "issues": "2-3 specific problems or risks you see in their numbers. Be direct.",
  "action_steps": "3-4 concrete things they should do immediately, written as a flowing paragraph.",
  "strategy": "Big picture long-term strategy advice, 2-3 sentences. What should their financial life look like in 10 years?"
}}"""

    try:
        raw = _call_claude(prompt)
        raw = raw.strip()
        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]
        return json.loads(raw.strip())
    except Exception as e:
        return {
            "summary":      "Your simulation results are displayed above.",
            "issues":       f"AI advisor temporarily unavailable. ({e})",
            "action_steps": "Please try again or review your numbers manually.",
            "strategy":     "Focus on increasing your savings rate and reducing high-interest debt.",
        }


def get_kids_advice(data: dict) -> str:
    goals_str = ""
    if data.get("goals"):
        goals_str = "Saving goals: " + ", ".join([f"{g['name']} (${g['cost']})" for g in data["goals"]])

    prompt = f"""You are an enthusiastic, fun money coach for kids aged 8-14. Use simple words and emojis.
Keep it to 3-4 short paragraphs. No bullet points. Be like a cool older friend.

Their situation:
- Monthly allowance: ${data.get('monthly_allowance', 0):.0f}
- Current savings: ${data.get('current_savings', 0):.0f}
- Monthly spending: ${data.get('monthly_spending', 0):.0f}
- Money owed: ${data.get('debt', 0):.0f}
- Saves per month: ${data.get('monthly_saved', 0):.0f}
- Savings rate: {data.get('savings_rate', 0)}%
- Final balance after {data.get('months', 12)} months: ${data.get('final_balance', 0):.0f}
{goals_str}

Give: a reaction to their savings rate, tips to reach goals faster, a fun compound interest fact, big encouraging ending!"""

    try:
        return _call_claude(prompt, max_tokens=600)
    except Exception as e:
        return "Wow, you're already thinking about saving money — that makes you smarter than most adults! 🌟 Keep it up!"
