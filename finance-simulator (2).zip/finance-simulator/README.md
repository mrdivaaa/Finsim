# 💹 FinSim Pro — Production Finance Simulator

## Setup

```bash
pip install -r requirements.txt
cp .env.example .env          # fill in ANTHROPIC_API_KEY
python app.py
```
Open http://localhost:5000

## New Features (Production Upgrade)

| Feature | Details |
|---|---|
| **Tax Engine** | 10 countries: US, UK, CA, AU, DE, FR, IN, SG, KE, ZA |
| **Salary Toggle** | Switch between monthly / annual input |
| **SQLite Database** | Auto-saves every simulation; view history in Saved tab |
| **Validation** | Frontend + backend with realistic financial limits |
| **Risk Scenarios** | Market crash, inflation spike, job loss, bear market |
| **Goal Tracker** | Persistent goals with progress bars, months-to-reach |
| **Structured AI** | 4-section report: Summary / Issues / Action Steps / Strategy |
| **Kids Mode** | Full allowance simulator with AI money coach |

## Architecture

```
app.py          — Flask routes (REST API)
simulator.py    — Financial math + risk scenarios
tax_engine.py   — Modular country tax system
ai_advisor.py   — Claude API (structured JSON advice)
validators.py   — Input validation (frontend + backend)
database.py     — SQLite persistence layer
templates/
  index.html    — Full SPA (dark fintech dashboard)
```

## Adding a New Country

In `tax_engine.py`, add to `TAX_PROFILES`:
```python
"MY": {
    "name": "Malaysia",
    "currency": "MYR",
    "symbol": "RM",
    "brackets": [(5000, 0.01), (20000, 0.03), ...],
    "social_security_rate": 0.11,
    "social_security_cap": float("inf"),
    "standard_deduction": 9000,
}
```

## Deploy to Railway

```bash
pip freeze > requirements.txt
railway login && railway init && railway up
railway variables set ANTHROPIC_API_KEY=sk-...
railway variables set SECRET_KEY=$(python -c "import secrets; print(secrets.token_hex(32))")
railway variables set FLASK_ENV=production
```
