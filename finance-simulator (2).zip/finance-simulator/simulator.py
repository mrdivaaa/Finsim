"""
Core financial simulation engine.
Supports base simulation, what-if scenarios, risk scenarios, and goal tracking.
"""


def simulate(salary, monthly_expenses, savings_rate, debt, annual_return,
             years, balance=0, inflation_rate=2.5):
    monthly_income  = salary / 12
    monthly_savings = monthly_income * (savings_rate / 100)
    net_worth       = balance - debt
    total_invested  = 0
    results         = []

    for year in range(1, years + 1):
        annual_savings   = monthly_savings * 12
        total_invested  += annual_savings
        net_worth        = (net_worth * (1 + annual_return / 100)) + annual_savings
        inflation_factor = (1 + inflation_rate / 100) ** year
        real_net_worth   = net_worth / inflation_factor
        annual_expenses  = monthly_expenses * 12 * inflation_factor

        results.append({
            "year":             year,
            "net_worth":        round(net_worth, 2),
            "real_net_worth":   round(real_net_worth, 2),
            "total_invested":   round(total_invested, 2),
            "investment_gains": round(net_worth - total_invested + debt - balance, 2),
            "annual_savings":   round(annual_savings, 2),
            "annual_expenses":  round(annual_expenses, 2),
        })

    return results


def what_if(salary, monthly_expenses, savings_rate, debt, annual_return,
            years, balance=0, extra_savings_pct=0, extra_return=0, inflation_rate=2.5):
    return simulate(
        salary=salary, monthly_expenses=monthly_expenses,
        savings_rate=savings_rate + extra_savings_pct, debt=debt,
        annual_return=annual_return + extra_return,
        years=years, balance=balance, inflation_rate=inflation_rate,
    )


# ---- Risk Scenarios ----

RISK_PROFILES = {
    "market_crash": {
        "label":       "Market Crash (2008-style)",
        "description": "A severe downturn hits year 3, wiping ~40% of portfolio value, then recovering at normal rate.",
        "icon":        "📉",
        "color":       "#ff4d6d",
    },
    "inflation_spike": {
        "label":       "Inflation Spike",
        "description": "Inflation surges to 8% for 5 years, severely eroding purchasing power.",
        "icon":        "🔥",
        "color":       "#ff9a3c",
    },
    "job_loss": {
        "label":       "Job Loss (1 Year)",
        "description": "You lose all income in year 2 for 12 months, drawing down savings for expenses.",
        "icon":        "💼",
        "color":       "#c77dff",
    },
    "bear_market": {
        "label":       "Prolonged Bear Market",
        "description": "Returns are flat (0%) for the first 5 years before recovering.",
        "icon":        "🐻",
        "color":       "#4cc9f0",
    },
}


def simulate_risk(salary, monthly_expenses, savings_rate, debt, annual_return,
                  years, balance=0, inflation_rate=2.5, scenario="market_crash"):
    monthly_income  = salary / 12
    monthly_savings = monthly_income * (savings_rate / 100)
    net_worth       = balance - debt
    total_invested  = 0
    results         = []

    for year in range(1, years + 1):
        effective_return  = annual_return
        effective_savings = monthly_savings
        crash_loss        = 0
        eff_inflation     = inflation_rate

        if scenario == "market_crash" and year == 3:
            crash_loss = max(0, net_worth) * 0.40
            net_worth -= crash_loss

        if scenario == "inflation_spike" and year <= 5:
            eff_inflation = 8.0

        if scenario == "bear_market" and year <= 5:
            effective_return = 0.0

        if scenario == "job_loss" and year == 2:
            effective_savings = -monthly_expenses  # drawing down

        annual_savings   = effective_savings * 12
        total_invested  += max(0, annual_savings)
        net_worth        = (net_worth * (1 + effective_return / 100)) + annual_savings
        inflation_factor = (1 + eff_inflation / 100) ** year
        real_net_worth   = net_worth / inflation_factor
        annual_expenses  = monthly_expenses * 12 * inflation_factor

        results.append({
            "year":             year,
            "net_worth":        round(net_worth, 2),
            "real_net_worth":   round(real_net_worth, 2),
            "total_invested":   round(total_invested, 2),
            "investment_gains": round(net_worth - total_invested + debt - balance, 2),
            "annual_savings":   round(annual_savings, 2),
            "annual_expenses":  round(annual_expenses, 2),
            "crash_loss":       round(crash_loss, 2),
        })

    return results


def get_summary(results, salary, debt, balance=0):
    final = results[-1]
    first_positive = next((r["year"] for r in results if r["net_worth"] > 0), None)
    fire_year = next(
        (r["year"] for r in results if r["net_worth"] >= r["annual_expenses"] * 25),
        None
    )
    return {
        "final_net_worth":      final["net_worth"],
        "final_real_net_worth": final["real_net_worth"],
        "total_invested":       final["total_invested"],
        "total_gains":          final["investment_gains"],
        "debt_free_year":       first_positive if debt > 0 else 0,
        "fire_year":            fire_year,
        "years_simulated":      len(results),
    }


def compute_goal_progress(goals: list, monthly_savings: float, current_net_worth: float) -> list:
    enriched = []
    for g in goals:
        remaining    = max(0, g["target_amount"] - g.get("current_amount", 0))
        progress     = (g.get("current_amount", 0) / g["target_amount"] * 100) if g["target_amount"] > 0 else 0
        months_need  = (remaining / monthly_savings) if monthly_savings > 0 else None
        deadline     = g.get("deadline_months")
        on_track     = (months_need <= deadline) if (months_need is not None and deadline) else True

        enriched.append({
            **g,
            "remaining":     round(remaining, 2),
            "progress_pct":  round(progress, 1),
            "months_needed": round(months_need, 1) if months_need is not None else None,
            "on_track":      on_track,
        })
    return enriched
