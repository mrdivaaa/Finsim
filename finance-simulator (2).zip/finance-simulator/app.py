"""
FinSim — Production Flask App
Environment variables:
  ANTHROPIC_API_KEY  — required for AI advice
  SECRET_KEY         — Flask session secret (defaults to random if not set)
  FLASK_ENV          — 'production' or 'development'
"""

import os
from flask import Flask, render_template, request, jsonify

from simulator import (
    simulate, what_if, simulate_risk,
    get_summary, compute_goal_progress, RISK_PROFILES
)
from ai_advisor import get_ai_advice, get_kids_advice
from tax_engine import calculate_tax, get_country_list
from validators import validate_simulation_inputs, validate_goal_input
from database import init_db, save_simulation, get_simulation, list_simulations, delete_simulation, save_goal, list_goals, delete_goal

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", os.urandom(24))

# Initialise DB on startup
init_db()


# ---- Pages ----

@app.route("/")
def index():
    countries = get_country_list()
    return render_template("index.html", countries=countries)


# ---- Core Simulation ----

@app.route("/api/simulate", methods=["POST"])
def run_simulation():
    try:
        validated = validate_simulation_inputs(request.get_json() or {})
    except ValueError as e:
        return jsonify({"error": str(e)}), 400

    raw = request.get_json()
    country_code = raw.get("country", "US")
    label        = str(raw.get("label", ""))[:80] or None

    # Tax calculation
    tax_info = calculate_tax(validated["salary"], country_code)
    net_salary = tax_info["net_annual"]

    # Run simulation on NET salary
    params = {**validated, "salary": net_salary}
    results  = simulate(**{k: params[k] for k in
                           ["salary","monthly_expenses","savings_rate","debt",
                            "annual_return","years","balance","inflation_rate"]})
    summary  = get_summary(results, net_salary, validated["debt"], validated["balance"])

    # What-if scenarios
    base_params = dict(salary=net_salary, monthly_expenses=validated["monthly_expenses"],
                       savings_rate=validated["savings_rate"], debt=validated["debt"],
                       annual_return=validated["annual_return"], years=validated["years"],
                       balance=validated["balance"], inflation_rate=validated["inflation_rate"])

    scenario_save_more      = what_if(**base_params, extra_savings_pct=5)
    scenario_better_returns = what_if(**base_params, extra_return=2)

    # Risk scenarios
    risk_results = {}
    for key in RISK_PROFILES:
        risk_results[key] = simulate_risk(**base_params, scenario=key)

    # AI advice
    advice = get_ai_advice(
        user_data={**validated, "symbol": tax_info["symbol"]},
        summary=summary,
        tax_info=tax_info,
    )

    # Persist
    sim_id = save_simulation(
        inputs=validated, results=results, summary=summary,
        tax_info=tax_info, advice=str(advice), label=label
    )

    return jsonify({
        "sim_id":                 sim_id,
        "results":                results,
        "summary":                summary,
        "tax_info":               tax_info,
        "scenario_save_more":     scenario_save_more,
        "scenario_better_returns":scenario_better_returns,
        "risk_results":           risk_results,
        "risk_profiles":          RISK_PROFILES,
        "advice":                 advice,
    })


# ---- Goals ----

@app.route("/api/goals", methods=["GET"])
def get_goals():
    return jsonify(list_goals())


@app.route("/api/goals", methods=["POST"])
def create_goal():
    try:
        validated = validate_goal_input(request.get_json() or {})
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    goal_id = save_goal(**validated)
    return jsonify({"goal_id": goal_id}), 201


@app.route("/api/goals/<goal_id>", methods=["DELETE"])
def remove_goal(goal_id):
    delete_goal(goal_id)
    return jsonify({"deleted": goal_id})


# ---- Saved Simulations ----

@app.route("/api/simulations", methods=["GET"])
def get_simulations():
    return jsonify(list_simulations())


@app.route("/api/simulations/<sim_id>", methods=["GET"])
def get_sim(sim_id):
    sim = get_simulation(sim_id)
    if not sim:
        return jsonify({"error": "Not found"}), 404
    return jsonify(sim)


@app.route("/api/simulations/<sim_id>", methods=["DELETE"])
def del_sim(sim_id):
    delete_simulation(sim_id)
    return jsonify({"deleted": sim_id})


# ---- Kids Advice ----

@app.route("/api/kids-advice", methods=["POST"])
def kids_advice():
    data = request.get_json() or {}
    advice = get_kids_advice(data)
    return jsonify({"advice": advice})


# ---- Meta ----

@app.route("/api/countries")
def countries():
    return jsonify(get_country_list())


@app.route("/health")
def health():
    return jsonify({"status": "ok"})


if __name__ == "__main__":
    debug = os.environ.get("FLASK_ENV", "development") != "production"
    app.run(debug=debug, host="0.0.0.0", port=int(os.environ.get("PORT", 5000)))
