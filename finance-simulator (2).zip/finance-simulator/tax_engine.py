"""
Modular tax engine. Add new countries by inserting into TAX_PROFILES.
Each profile specifies brackets (marginal) or a flat rate, plus social security / NI.
"""

from typing import Tuple

TAX_PROFILES = {
    "US": {
        "name": "United States",
        "currency": "USD",
        "symbol": "$",
        "brackets": [
            (11600,  0.10),
            (47150,  0.12),
            (100525, 0.22),
            (191950, 0.24),
            (243725, 0.32),
            (609350, 0.35),
            (float("inf"), 0.37),
        ],
        "social_security_rate": 0.0765,  # FICA employee share
        "social_security_cap": 160200,
        "standard_deduction": 14600,
    },
    "UK": {
        "name": "United Kingdom",
        "currency": "GBP",
        "symbol": "£",
        "brackets": [
            (12570,  0.00),
            (50270,  0.20),
            (125140, 0.40),
            (float("inf"), 0.45),
        ],
        "social_security_rate": 0.08,   # NI primary rate
        "social_security_cap": 50270,
        "standard_deduction": 0,
    },
    "CA": {
        "name": "Canada",
        "currency": "CAD",
        "symbol": "C$",
        "brackets": [
            (15705,  0.00),
            (55867,  0.15),
            (111733, 0.205),
            (154906, 0.26),
            (220000, 0.29),
            (float("inf"), 0.33),
        ],
        "social_security_rate": 0.0595,  # CPP + EI approximate
        "social_security_cap": 66600,
        "standard_deduction": 0,
    },
    "AU": {
        "name": "Australia",
        "currency": "AUD",
        "symbol": "A$",
        "brackets": [
            (18200,  0.00),
            (45000,  0.19),
            (120000, 0.325),
            (180000, 0.37),
            (float("inf"), 0.45),
        ],
        "social_security_rate": 0.0,   # Medicare 2% included below
        "medicare_levy": 0.02,
        "social_security_cap": float("inf"),
        "standard_deduction": 0,
    },
    "DE": {
        "name": "Germany",
        "currency": "EUR",
        "symbol": "€",
        "flat_rate": 0.30,   # approx average mid-income
        "social_security_rate": 0.195,  # health+pension+unemp employee share
        "social_security_cap": 87600,
        "standard_deduction": 0,
    },
    "FR": {
        "name": "France",
        "currency": "EUR",
        "symbol": "€",
        "brackets": [
            (10777,  0.00),
            (27478,  0.11),
            (78570,  0.30),
            (168994, 0.41),
            (float("inf"), 0.45),
        ],
        "social_security_rate": 0.22,
        "social_security_cap": float("inf"),
        "standard_deduction": 0,
    },
    "IN": {
        "name": "India",
        "currency": "INR",
        "symbol": "₹",
        "brackets": [
            (300000,      0.00),
            (600000,      0.05),
            (900000,      0.10),
            (1200000,     0.15),
            (1500000,     0.20),
            (float("inf"), 0.30),
        ],
        "social_security_rate": 0.12,  # PF employee
        "social_security_cap": float("inf"),
        "standard_deduction": 50000,
    },
    "SG": {
        "name": "Singapore",
        "currency": "SGD",
        "symbol": "S$",
        "brackets": [
            (20000,  0.00),
            (30000,  0.02),
            (40000,  0.035),
            (80000,  0.07),
            (120000, 0.115),
            (160000, 0.15),
            (200000, 0.18),
            (240000, 0.19),
            (280000, 0.195),
            (320000, 0.20),
            (float("inf"), 0.22),
        ],
        "social_security_rate": 0.20,  # CPF employee
        "social_security_cap": 102000,
        "standard_deduction": 0,
    },
    "KE": {
        "name": "Kenya",
        "currency": "KES",
        "symbol": "KSh",
        "brackets": [
            (288000,      0.10),
            (388000,      0.25),
            (float("inf"), 0.30),
        ],
        "social_security_rate": 0.06,   # NSSF + NHIF approx
        "social_security_cap": float("inf"),
        "standard_deduction": 0,
        "personal_relief": 28800,
    },
    "ZA": {
        "name": "South Africa",
        "currency": "ZAR",
        "symbol": "R",
        "brackets": [
            (237100,      0.18),
            (370500,      0.26),
            (512800,      0.31),
            (673000,      0.36),
            (857900,      0.39),
            (1817000,     0.41),
            (float("inf"), 0.45),
        ],
        "social_security_rate": 0.01,
        "social_security_cap": float("inf"),
        "standard_deduction": 17235,
        "personal_rebate": 17235,
    },
    "NO_TAX": {
        "name": "No Tax / Other",
        "currency": "USD",
        "symbol": "$",
        "flat_rate": 0.0,
        "social_security_rate": 0.0,
        "social_security_cap": float("inf"),
        "standard_deduction": 0,
    },
}


def calculate_tax(annual_gross: float, country_code: str) -> dict:
    """
    Returns a dict with gross, income_tax, social_security, total_tax, net_income, effective_rate.
    """
    profile = TAX_PROFILES.get(country_code, TAX_PROFILES["NO_TAX"])

    gross = annual_gross
    deduction = profile.get("standard_deduction", 0)
    taxable = max(0, gross - deduction)

    # --- Income tax ---
    if "flat_rate" in profile:
        income_tax = taxable * profile["flat_rate"]
    else:
        income_tax = _bracket_tax(taxable, profile["brackets"])

    # personal rebate (South Africa style)
    income_tax = max(0, income_tax - profile.get("personal_rebate", 0))
    # personal relief (Kenya style)
    income_tax = max(0, income_tax - profile.get("personal_relief", 0))
    # Medicare levy (Australia)
    income_tax += gross * profile.get("medicare_levy", 0)

    # --- Social security ---
    ss_base = min(gross, profile.get("social_security_cap", float("inf")))
    social_security = ss_base * profile.get("social_security_rate", 0)

    total_tax = income_tax + social_security
    net_income = gross - total_tax
    effective_rate = (total_tax / gross * 100) if gross > 0 else 0

    return {
        "country": profile["name"],
        "currency": profile["currency"],
        "symbol": profile.get("symbol", "$"),
        "gross_annual": round(gross, 2),
        "income_tax": round(income_tax, 2),
        "social_security": round(social_security, 2),
        "total_tax": round(total_tax, 2),
        "net_annual": round(net_income, 2),
        "net_monthly": round(net_income / 12, 2),
        "effective_rate": round(effective_rate, 1),
    }


def _bracket_tax(income: float, brackets: list) -> float:
    tax = 0.0
    prev = 0.0
    for ceiling, rate in brackets:
        if income <= prev:
            break
        taxable_in_band = min(income, ceiling) - prev
        tax += taxable_in_band * rate
        prev = ceiling
    return tax


def get_country_list() -> list:
    return [
        {"code": k, "name": v["name"], "symbol": v.get("symbol", "$")}
        for k, v in TAX_PROFILES.items()
    ]
